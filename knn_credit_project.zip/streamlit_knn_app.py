import streamlit as st
import numpy as np
import joblib

model = joblib.load("model/knn_credit_model.pkl")
scaler = joblib.load("model/scaler.pkl")

st.title("Prediksi Default Nasabah Kartu Kredit")
LIMIT_BAL = st.number_input("Limit Kredit", min_value=0)
SEX = st.selectbox("Jenis Kelamin", [1, 2])
EDUCATION = st.selectbox("Pendidikan", [1, 2, 3, 4])
MARRIAGE = st.selectbox("Status Pernikahan", [1, 2, 3])
AGE = st.slider("Usia", 18, 100, 30)
PAY_0 = st.number_input("PAY_0", -2, 8)
PAY_2 = st.number_input("PAY_2", -2, 8)
PAY_3 = st.number_input("PAY_3", -2, 8)
PAY_4 = st.number_input("PAY_4", -2, 8)
PAY_5 = st.number_input("PAY_5", -2, 8)
PAY_6 = st.number_input("PAY_6", -2, 8)
BILL_AMTs = [st.number_input(f"BILL_AMT{i}", min_value=0) for i in range(1, 7)]
PAY_AMTs = [st.number_input(f"PAY_AMT{i}", min_value=0) for i in range(1, 7)]
input_data = [LIMIT_BAL, SEX, EDUCATION, MARRIAGE, AGE, PAY_0, PAY_2, PAY_3, PAY_4, PAY_5, PAY_6, *BILL_AMTs, *PAY_AMTs]

if st.button("Prediksi"):
    input_scaled = scaler.transform([input_data])
    prediction = model.predict(input_scaled)[0]
    if prediction == 1:
        st.error("❌ Diprediksi GAGAL BAYAR")
    else:
        st.success("✅ Diprediksi TIDAK gagal bayar")